

import java.util.Iterator;


public class Hashtable<K, V> {
	private Entry<K,V>[] values;
	private int size;
	
	public Hashtable(int initialCapacity) {
		values = (Entry<K,V>[])new Entry[initialCapacity];
	}
	
	/**
	 * #3b. Implement this (1 point)
	 * 
	 * @param key
	 * @param value
	 */
	public void put(K key, V value) 
	{
		int hash = key.hashCode() % values.length;
		if(values[hash] == null)
		{
			values[hash] = new Entry<K, V>(key, value);
			size++;
		}
		else
		{
			boolean entryFound = false;
			Entry currentEntry = values[hash];
			Entry previousEntry = null;
			
			while(currentEntry != null && !entryFound)
			{
				if(currentEntry.key.equals(key))
				{
					entryFound = true;
				}
				else
				{
					previousEntry = currentEntry;
					currentEntry = currentEntry.next;
				}
			}
			
			if(entryFound)
			{
				currentEntry.data = value;
			}
			else
			{
				previousEntry.next = new Entry<K, V>(key, value);
			}
		}
	}
	
	/**
	 * #3b. Implement this (1 point)
	 * @param key
	 * @return
	 */
	public V get(K key) {
		
		if(key.equals(null))
		{
			throw new NullPointerException("Key cannot be null");
		}
		
		int hash = key.hashCode() % values.length;
		if(values[hash] == null)
		{
			return null;
		}
		
		boolean entryFound = false;
		V dataToGet = null;
		Entry currentEntry = values[hash];
		
		while(currentEntry != null)
		{
			if(currentEntry.key.equals(key))
			{
				entryFound = true;
				dataToGet = (V) currentEntry.data;
			}
		}
		
		return dataToGet;
	}

	/**
	 * #3c.  Implement this. (1 point)
	 * 
	 * @param key
	 * @return
	 */
	public V remove(K key) 
	{
		if(key.equals(null))
		{
			throw new NullPointerException("Key cannot be null");
		}
		
		V dataToRemove = null;
		int hash = key.hashCode() % values.length;
		if(values[hash] == null)
		{
			return null;
		}
		else
		{
			boolean entryFound = false;
			Entry currentEntry = values[hash];
			Entry previousEntry = null;
			
			while(currentEntry != null && !entryFound)
			{
				if(currentEntry.key.equals(key))
				{
					entryFound = true;
					dataToRemove = (V) currentEntry.data;
					previousEntry.next = currentEntry.next;
					currentEntry = null;
				}
				else
				{
					previousEntry = currentEntry;
					currentEntry = currentEntry.next;
				}
			}
		}
		
		return (V)dataToRemove;
	}
	
	public int size() {
		return size;
	}
	
	public boolean containsKey(K key) {
		return this.get(key) != null; 
	}

	public Iterator<V> values() {
		return new Iterator<V>() {
			private int count = 0;
			private Entry<K, V> currentEntry;
			
			{
				while ( ( currentEntry = values[count] ) == null && count < values.length ) {
					count++;
				}
			}

			@Override
			public boolean hasNext() {
				return count < values.length;
			}

			@Override
			public V next() {
				V toReturn = currentEntry.data;
				currentEntry = currentEntry.next;
				while ( currentEntry == null && ++count < values.length && (currentEntry = values[count]) == null );
				return toReturn;
			}

			@Override
			public void remove() {
			}
			
		};
	}
	
	private static class Entry<K, V> {
		private K key;
		private V data;
		private Entry<K,V> next;
		
		public Entry(K key, V data) {
			this.key = key;
			this.data = data;
		}
		
		public String toString() {
			return "{" + key + "=" + data + "}";
		}
	}
}